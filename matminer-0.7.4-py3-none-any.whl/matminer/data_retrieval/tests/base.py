import os

on_ci = os.environ.get("RUNNING_ON_GHACTIONS", "")
