"""
IO for LAMMPS
"""
