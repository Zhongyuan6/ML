"""
Package for analyzing ferroelectricity.
"""
